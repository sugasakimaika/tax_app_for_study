# my_app_for_Womanmoneycareer

##目標
* ChatGptApi使用
* Pyhonで税務系のアプリを作成したい
* 紙ベースの問題が多くて勉強するハードルが高いため
* us east2で運用
