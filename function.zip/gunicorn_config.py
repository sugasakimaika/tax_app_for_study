bind = '0.0.0.0:8000'
workers = 4
accesslog = '/path/to/access.log'
errorlog = '/path/to/error.log'
timeout = 30


